//<!--Autor do Arquivo: @Allan Gaiteiro -->//

function clicou(n){
    document.querySelector(`#${n}`).style.opacity= 1
}

function fechar(n){
    document.querySelector(`#${n}`).style.opacity= 0
}
